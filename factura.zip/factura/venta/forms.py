from django import forms
from django.forms.models import inlineformset_factory
from .models import Factura, DetalleFactura

class FacturaForm(forms.ModelForm):
    class Meta:
        model = Factura
        fields = ['folio', 'cliente', 'vendedor', 'forma_de_pago']

class DetalleFacturaForm(forms.ModelForm):
    class Meta:
        model = DetalleFactura
        fields = ['producto', 'cantidad', 'precio_unitario', 'subtotal']
        widgets = {
            'producto': forms.Select(attrs={'class': 'form-control'}),
            'cantidad': forms.NumberInput(attrs={'class': 'form-control'}),
            'precio_unitario': forms.NumberInput(attrs={'class': 'form-control'}),
            'subtotal': forms.NumberInput(attrs={'class': 'form-control'}),
        }

DetalleFacturaFormSet = inlineformset_factory(
    Factura, DetalleFactura, form=DetalleFacturaForm, extra=1, can_delete=True
)
