from django.shortcuts import render, redirect
from django.views.generic import View
from .models import Factura
from .forms import FacturaForm, DetalleFacturaFormSet

class CrearFacturaView(View):
    def get(self, request):
        factura_form = FacturaForm()
        detalle_formset = DetalleFacturaFormSet()
        return render(request, 'crear_factura.html', {
            'factura_form': factura_form,
            'detalle_formset': detalle_formset
        })

    def post(self, request):
        factura_form = FacturaForm(request.POST)
        detalle_formset = DetalleFacturaFormSet(request.POST)

        if factura_form.is_valid() and detalle_formset.is_valid():
            factura = factura_form.save()
            detalles = detalle_formset.save(commit=False)
            for detalle in detalles:
                detalle.factura = factura
                detalle.save()
            return redirect('listar_facturas')  # Redirige a una página de resumen de facturas

        return render(request, 'crear_factura.html', {
            'factura_form': factura_form,
            'detalle_formset': detalle_formset
        })

def listar_facturas_view(request):
    facturas = Factura.objects.all()
    return render(request, 'listar_facturas.html', {'facturas': facturas})
                                                   
def editar_factura_view(request):
    pass

def eliminar_factura_view(request):
    pass 