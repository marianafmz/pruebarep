from django.db import models

class Cliente(models.Model):
    nombre = models.CharField(max_length=100)
 
    def __str__(self):
        return f"{self.nombre}"

class Producto(models.Model):
    clave = models.CharField(max_length=10)
    descripcion = models.TextField()
    precio_unitario = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.clave} - {self.descripcion}"

class Vendedor(models.Model):
    nombre = models.CharField(max_length=100)
    
    def __str__(self):
        return f"{self.nombre}"

class Factura(models.Model):
    folio = models.CharField(max_length=20, unique=True)
    fecha_hora = models.DateTimeField(auto_now_add=True)
    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE)
    vendedor = models.ForeignKey(Vendedor, on_delete=models.CASCADE)
    forma_de_pago = models.CharField(max_length=50)
    
    def calcular_totales(self):
        subtotal = sum(detalle.subtotal for detalle in self.detalles.all())
        impuestos = subtotal * 1
        total = subtotal + impuestos
        return {
            'subtotal': subtotal,
            'impuestos': impuestos,
            'total': total
        }

class DetalleFactura(models.Model):
    factura = models.ForeignKey(Factura, on_delete=models.CASCADE, related_name="detalles")
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidad = models.IntegerField()
    precio_unitario = models.DecimalField(max_digits=10, decimal_places=2) 
    subtotal = models.DecimalField(max_digits=10, decimal_places=2)

    def save(self, *args, **kwargs):
        self.subtotal = self.cantidad * self.producto.precio_unitario
        super().save(*args, **kwargs)
