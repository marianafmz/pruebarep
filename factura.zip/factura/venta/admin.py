from django.contrib import admin
from .models import Cliente, Producto, Vendedor, Factura, DetalleFactura

class DetalleFacturaInline(admin.TabularInline):  # Puedes usar StackedInline si prefieres un diseño vertical
    model = DetalleFactura
    extra = 1  # Número de formularios vacíos que se mostrarán por defecto
    fields = ['producto', 'cantidad', 'precio_unitario','subtotal']
    readonly_fields = ['subtotal']  # Hace el campo subtotal solo de lectura

    def get_readonly_fields(self, request, obj=None):
        # Opcional: permitir la edición de subtotales en ciertas condiciones
        return self.readonly_fields

class FacturaAdmin(admin.ModelAdmin):
    list_display = ['folio', 'cliente', 'vendedor', 'fecha_hora', 'forma_de_pago']
    inlines = [DetalleFacturaInline]  # Incluye los detalles de factura en el formulario
    search_fields = ['folio', 'cliente__nombre']
    list_filter = ['fecha_hora', 'vendedor']


# Register your models here.
admin.site.register(Cliente)
admin.site.register(Producto)
admin.site.register(Vendedor)
admin.site.register(Factura, FacturaAdmin)