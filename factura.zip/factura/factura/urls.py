"""
URL configuration for factura project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from venta.views import CrearFacturaView, listar_facturas_view, editar_factura_view, eliminar_factura_view

urlpatterns = [
    path('admin/', admin.site.urls),
    path('crear_factura/', CrearFacturaView.as_view(), name='crear_factura'),
    path('listar_facturas/', listar_facturas_view, name='listar_facturas'), 
    path('editar_factura/<int:id>', editar_factura_view, name='editar_factura'), 
    path('eliminar_factura/<int:id>', eliminar_factura_view, name='eliminar_factura'), 
]

